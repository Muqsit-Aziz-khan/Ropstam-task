<?php
/*
Plugin Name: Website Form Plugin
Description: 
Version: 1.0
Author: Muqsit aziz
*/

function register_post_type_websites() {
    $args = array(
        'public' => true,
        'label'  => 'WEBSITES',
        'supports' => array('title'),
        'show_ui' => current_user_can( 'administrator' ) || current_user_can( 'editor' ),
    );
    register_post_type( 'websites', $args );
}
add_action( 'init', 'register_post_type_websites' );

function remove_metaboxes() {
    if ( ! current_user_can( 'administrator' ) ) {
        remove_meta_box( 'submitdiv', 'websites', 'side' );
    }
}
add_action( 'admin_menu', 'remove_metaboxes' );

function add_custom_metabox() {
    add_meta_box(
        'website_source_code',
        'Website Source Code',
        'render_custom_metabox',
        'websites',
        'normal',
        'default'
    );
}
add_action( 'add_meta_boxes', 'add_custom_metabox' );

function render_custom_metabox( $post ) {
    if ( current_user_can( 'administrator' ) ) {
        $website_url = get_post_meta( $post->ID, 'website_url', true );
        if ( ! empty( $website_url ) ) {
            $website_source_code = file_get_contents( $website_url );
            ?>
            <label for="website-source-code">Source Code:</label><br>
            <textarea id="website-source-code" name="website_source_code" rows="10" style="width: 100%;"><?php echo esc_textarea( $website_source_code ); ?></textarea>
            <?php
        } else {
            echo 'No website URL provided.';
        }
    } else {
        echo 'You do not have permission to view this content.';
    }
}

function save_custom_metabox( $post_id ) {
    if ( ! isset( $_POST['website_source_code_nonce'] ) || ! wp_verify_nonce( $_POST['website_source_code_nonce'], 'website_source_code_nonce' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( 'websites' !== $_POST['post_type'] ) {
        return;
    }

    if ( isset( $_POST['website_source_code'] ) ) {
        update_post_meta( $post_id, 'website_source_code', wp_kses_post( $_POST['website_source_code'] ) );
    }
}
add_action( 'save_post', 'save_custom_metabox' );

function disable_new_post_creation() {
    global $pagenow;
    if ( $pagenow == 'post-new.php' && isset( $_GET['post_type'] ) && $_GET['post_type'] == 'websites' ) {
        wp_die( 'You are not allowed to create new WEBSITES.' );
    }
}
add_action( 'admin_init', 'disable_new_post_creation' );

function add_form() {
    ?>
    <form id="website-form" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post">
        <label for="visitor-name">Your Name:</label><br>
        <input type="text" id="visitor-name" name="visitor_name" required><br>
        <label for="website-url">Website URL:</label><br>
        <input type="url" id="website-url" name="website_url" required><br><br>
        <input type="submit" value="Submit">
        <input type="hidden" name="action" value="website_form_submission">
        <?php wp_nonce_field( 'website_form_nonce', 'website_form_nonce_field' ); ?>
    </form>
    <?php
}
add_shortcode( 'website_form', 'add_form' );

function process_form() {
    if ( ! isset( $_POST['website_form_nonce_field'] ) || ! wp_verify_nonce( $_POST['website_form_nonce_field'], 'website_form_nonce' ) ) {
        return;
    }

    $visitor_name = sanitize_text_field( $_POST['visitor_name'] );
    $website_url = esc_url_raw( $_POST['website_url'] );

    $post_data = array(
        'post_title'    => $visitor_name . ' - ' . $website_url,
        'post_status'   => 'publish',
        'post_type'     => 'websites',
    );

    $post_id = wp_insert_post( $post_data );

    if ( is_wp_error( $post_id ) ) {
        wp_die( 'Error creating post: ' . $post_id->get_error_message() );
    } else {
        update_post_meta( $post_id, 'website_url', $website_url );
        wp_redirect( home_url() ); 
        exit;
    }
}
add_action( 'admin_post_website_form_submission', 'process_form' );
add_action( 'admin_post_nopriv_website_form_submission', 'process_form' );
?>